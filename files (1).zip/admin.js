import { auth, db } from "./firebase.js";
import { signInWithEmailAndPassword, signOut, onAuthStateChanged }
  from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { collection, doc, getDoc, onSnapshot }
  from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const niceDate = d => new Date(d + "T00:00").toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "long", year: "numeric" });
const fmtTs = t => t?.toDate ? t.toDate().toLocaleString() : "—";
let entries = [], logs = [], unsubs = [];

document.addEventListener("click", e => { if (e.target.matches("[data-close]") || e.target.classList.contains("modal")) $("#readModal").hidden = true; });
document.querySelectorAll(".tab").forEach(b => b.onclick = () => {
  document.querySelectorAll(".tab").forEach(t => { t.classList.toggle("active", t === b); t.classList.toggle("soft", t !== b); });
  ["entriesTab", "logsTab"].forEach(id => $("#" + id).hidden = id !== b.dataset.tab);
});

$("#loginForm").addEventListener("submit", async e => {
  e.preventDefault(); $("#loginErr").textContent = "";
  try { await signInWithEmailAndPassword(auth, $("#email").value.trim(), $("#password").value); }
  catch { $("#loginErr").textContent = "Those details aren't right."; }
});
$("#logoutBtn").onclick = () => signOut(auth);

onAuthStateChanged(auth, async user => {
  unsubs.forEach(u => u()); unsubs = [];
  $("#loginView").hidden = !!user; $("#appView").hidden = true;
  if (!user) return;
  // Authorisation: an admin has a document at admins/{uid}, created by hand in the Firebase console.
  let ok = false;
  try { ok = (await getDoc(doc(db, "admins", user.uid))).exists(); } catch {}
  if (!ok) { await signOut(auth); $("#loginErr").textContent = "This account doesn't have admin access."; return; }
  $("#appView").hidden = false;
  unsubs.push(onSnapshot(collection(db, "diaryEntries"), s => { entries = s.docs.map(d => ({ id: d.id, ...d.data() })); fillTopics(); render(); }));
  unsubs.push(onSnapshot(collection(db, "activityLogs"), s => {
    logs = s.docs.map(d => d.data()).sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
    $("#logs").innerHTML = logs.length ? logs.map(l => `<tr><td>${esc(l.userId)}</td><td><span class="chip">${esc(l.eventType)}</span></td><td>${esc(l.date)}</td><td>${esc(l.time)}</td><td>${fmtTs(l.createdAt)}</td></tr>`).join("")
      : `<tr><td colspan="5" style="text-align:center">No password events yet.</td></tr>`;
  }));
});

function fillTopics() {
  const sel = $("#topicFilter"), cur = sel.value;
  const topics = [...new Set(entries.map(e => e.topic))].sort();
  sel.innerHTML = `<option value="">All topics</option>` + topics.map(t => `<option ${t === cur ? "selected" : ""} value="${esc(t)}">${esc(t)}</option>`).join("");
}
function render() {
  const q = $("#search").value.toLowerCase(), d = $("#dateFilter").value, t = $("#topicFilter").value, dir = $("#order").value === "asc" ? 1 : -1;
  const list = entries.filter(e => (!d || e.date === d) && (!t || e.topic === t) && (!q || `${e.topic} ${e.content}`.toLowerCase().includes(q)))
    .sort((a, b) => dir * (a.date + (a.time || "")).localeCompare(b.date + (b.time || "")));
  $("#stats").textContent = `${entries.length} diary ${entries.length === 1 ? "entry" : "entries"}`;
  $("#entries").innerHTML = list.map(e => `<article class="card"><div class="date">📅 ${esc(niceDate(e.date))} · ${esc(e.time || "")}</div>
    <h3>${esc(e.topic)}</h3><p>${esc(e.content)}</p>
    <div class="meta" style="margin-bottom:.8rem">Created ${fmtTs(e.createdAt)}<br>Updated ${fmtTs(e.updatedAt)}</div>
    <div class="actions"><button class="btn sm" data-id="${e.id}">Read full entry</button></div></article>`).join("");
  $("#empty").hidden = list.length > 0;
}
["#search", "#dateFilter", "#topicFilter", "#order"].forEach(s => $(s).addEventListener("input", render));
$("#clearBtn").onclick = () => { $("#search").value = $("#dateFilter").value = $("#topicFilter").value = ""; render(); };
$("#entries").addEventListener("click", e => {
  const b = e.target.closest("[data-id]"); if (!b) return;
  const en = entries.find(x => x.id === b.dataset.id);
  $("#rDate").textContent = `📅 ${niceDate(en.date)} · ${en.time || ""}`; $("#rTopic").textContent = en.topic; $("#rBody").textContent = en.content;
  $("#rMeta").textContent = `Entry ID ${en.id} · Created ${fmtTs(en.createdAt)} · Updated ${fmtTs(en.updatedAt)}`; $("#readModal").hidden = false;
});
