import { auth, db } from "./firebase.js";
import { signInWithEmailAndPassword, signOut, onAuthStateChanged, EmailAuthProvider,
  reauthenticateWithCredential, updatePassword, sendPasswordResetEmail }
  from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { collection, doc, setDoc, getDoc, updateDoc, deleteDoc, addDoc, query, where, onSnapshot, serverTimestamp }
  from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const todayStr = () => new Date(Date.now() - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 10);
const nowTime = () => new Date().toTimeString().slice(0, 5);
const niceDate = d => new Date(d + "T00:00").toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "long", year: "numeric" });
const fmtTs = t => t?.toDate ? t.toDate().toLocaleString() : "—";
let entries = [], unsub = null, editingId = null, deletingId = null;

function toast(msg) { const t = $("#toast"); t.textContent = msg; t.classList.add("show"); setTimeout(() => t.classList.remove("show"), 2800); }
const show = id => ["listView", "composeView"].forEach(v => $("#" + v).hidden = v !== id);
const open = id => $("#" + id).hidden = false;
document.addEventListener("click", e => { if (e.target.matches("[data-close]") || e.target.classList.contains("modal")) document.querySelectorAll(".modal").forEach(m => m.hidden = true); });

/* ---------- auth ---------- */
$("#loginForm").addEventListener("submit", async e => {
  e.preventDefault(); $("#loginErr").textContent = "";
  try { await signInWithEmailAndPassword(auth, $("#email").value.trim(), $("#password").value); }
  catch { $("#loginErr").textContent = "That email or password isn't right. Please try again."; }
});
$("#forgotBtn").onclick = async () => {
  const em = $("#email").value.trim();
  if (!em) { $("#loginErr").textContent = "Enter your email above, then tap Forgot password."; return; }
  try { await sendPasswordResetEmail(auth, em); toast("Reset link sent. Check your inbox 💌"); } catch { $("#loginErr").textContent = "Couldn't send a reset link to that email."; }
};
$("#logoutBtn").onclick = () => signOut(auth);

onAuthStateChanged(auth, async user => {
  $("#loginView").hidden = !!user; $("#appView").hidden = !user;
  if (unsub) { unsub(); unsub = null; }
  if (!user) { entries = []; return; }
  const uref = doc(db, "users", user.uid);
  try { if (!(await getDoc(uref)).exists()) await setDoc(uref, { name: "Heena", email: user.email, createdAt: serverTimestamp() }); } catch {}
  unsub = onSnapshot(query(collection(db, "diaryEntries"), where("userId", "==", user.uid)), snap => {
    entries = snap.docs.map(d => ({ id: d.id, ...d.data() }))
      .sort((a, b) => (b.date + (b.time || "")).localeCompare(a.date + (a.time || "")));
    render();
  }, () => toast("Couldn't load entries. Check your Firestore rules."));
  show("listView");
});

/* ---------- list ---------- */
function render() {
  const q = $("#search").value.toLowerCase(), d = $("#dateFilter").value;
  const list = entries.filter(e => (!d || e.date === d) && (!q || `${e.topic} ${e.content}`.toLowerCase().includes(q)));
  $("#entries").innerHTML = list.map(e => `
    <article class="card"><div class="date">📅 ${esc(niceDate(e.date))}</div><h3>${esc(e.topic)}</h3>
    <p>${esc(e.content)}</p>
    <div class="actions" data-id="${e.id}"><button class="btn sm" data-act="read">Read</button>
    <button class="btn soft sm" data-act="edit">Edit</button><button class="btn danger sm" data-act="del">Delete</button></div></article>`).join("");
  $("#empty").hidden = list.length > 0;
}
["#search", "#dateFilter"].forEach(s => $(s).addEventListener("input", render));
$("#clearBtn").onclick = $("#allBtn").onclick = () => { $("#search").value = ""; $("#dateFilter").value = ""; render(); show("listView"); };

$("#entries").addEventListener("click", e => {
  const b = e.target.closest("[data-act]"); if (!b) return;
  const id = b.parentElement.dataset.id, en = entries.find(x => x.id === id);
  if (b.dataset.act === "read") {
    $("#rDate").textContent = "📅 " + niceDate(en.date) + (en.time ? " · " + en.time : "");
    $("#rTopic").textContent = en.topic; $("#rBody").textContent = en.content;
    $("#rMeta").textContent = `Written ${fmtTs(en.createdAt)} · Last edited ${fmtTs(en.updatedAt)}`; open("readModal");
  } else if (b.dataset.act === "edit") openCompose(en);
  else { deletingId = id; $("#delTopic").textContent = en.topic; open("deleteModal"); }
});
$("#confirmDelete").onclick = async () => {
  try { await deleteDoc(doc(db, "diaryEntries", deletingId)); toast("Entry deleted"); } catch { toast("Couldn't delete that entry."); }
  $("#deleteModal").hidden = true;
};

/* ---------- compose / edit ---------- */
function openCompose(en) {
  editingId = en?.id || null;
  $("#composeTitle").textContent = en ? "Edit your page" : "A new page";
  $("#composeHint").textContent = en ? "Change anything, then save." : "Today is yours. Write whatever your heart holds.";
  $("#eDate").value = en?.date || todayStr(); $("#eTopic").value = en?.topic || ""; $("#eContent").value = en?.content || "";
  show("composeView"); window.scrollTo({ top: 0, behavior: "smooth" }); $("#eTopic").focus();
}
$("#composeBtn").onclick = $("#emptyCompose").onclick = () => openCompose();
$("#cancelBtn").onclick = () => show("listView");
$("#entryForm").addEventListener("submit", async e => {
  e.preventDefault();
  const data = { date: $("#eDate").value, topic: $("#eTopic").value.trim(), content: $("#eContent").value.trim() };
  try {
    if (editingId) { await updateDoc(doc(db, "diaryEntries", editingId), { ...data, updatedAt: serverTimestamp() }); toast("Your page has been updated 💚"); }
    else {
      const ref = doc(collection(db, "diaryEntries"));
      await setDoc(ref, { entryId: ref.id, userId: auth.currentUser.uid, ...data, time: nowTime(), createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
      toast("Your memory has been saved 💚");
    }
    show("listView");
  } catch { toast("Couldn't save. Please check your connection and try again."); }
});

/* ---------- password ---------- */
$("#pwBtn").onclick = () => { $("#pwForm").reset(); $("#pwErr").textContent = ""; open("pwModal"); };
$("#pwForm").addEventListener("submit", async e => {
  e.preventDefault(); const err = $("#pwErr"); err.textContent = "";
  const cur = $("#curPw").value, n1 = $("#newPw").value;
  if (n1 !== $("#newPw2").value) return err.textContent = "The new passwords don't match.";
  if (n1 === cur) return err.textContent = "Choose a password different from your current one.";
  try {
    const u = auth.currentUser;
    await reauthenticateWithCredential(u, EmailAuthProvider.credential(u.email, cur));
    await updatePassword(u, n1);
  } catch { return err.textContent = "Couldn't update. Check your current password and use 6+ characters."; }
  try { // log the event only. The password itself is never stored.
    await addDoc(collection(db, "activityLogs"), { userId: auth.currentUser.uid, eventType: "Password Changed",
      date: todayStr(), time: new Date().toTimeString().slice(0, 8), createdAt: serverTimestamp(), timestamp: Date.now() });
  } catch {}
  $("#pwModal").hidden = true; toast("Password updated 🔐");
});
